package edu.westga.cs6312.polymorphism.view;

import edu.westga.cs6312.polymorphism.model.Animal;
import java.util.Scanner;
import java.util.ArrayList;


/**
 * Homework HW05  
 * @author 	cs6312
 * @author 	jim perry, jr.
 * @version	02.10.2016
 */
public class AnimalTUI {
	
	private Scanner userKeyboard;
	private ArrayList<Animal> animals;

	
	/**
	 * initialize the instance variable(s).
	 */	
	public AnimalTUI() {
		this.userKeyboard = new Scanner(System.in);
		this.animals = new ArrayList<Animal>();
	}
	
	
	/**
	 * controls program flow
	 **/
	public void run() {	
		
	}
}
